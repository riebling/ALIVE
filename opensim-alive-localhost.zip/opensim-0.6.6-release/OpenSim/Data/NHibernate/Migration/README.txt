This directory contains migration scripts for migrating from other
database backends in OpenSim to the NHibernate version of that same
database driver.