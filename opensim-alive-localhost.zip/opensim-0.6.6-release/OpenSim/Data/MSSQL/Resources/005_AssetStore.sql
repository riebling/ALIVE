DELETE FROM assets WHERE id = 'dc4b9f0b-d008-45c6-96a4-01dd947ac621';
