BEGIN;

delete from regionsettings;

COMMIT;
