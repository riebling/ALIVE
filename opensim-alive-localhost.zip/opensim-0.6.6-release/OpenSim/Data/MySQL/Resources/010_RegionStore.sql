# 1 "010_RegionStore.sql"
# 1 "<built-in>"
# 1 "<command line>"
# 1 "010_RegionStore.sql"
BEGIN;

DELETE FROM regionsettings;

COMMIT;
