BEGIN;

ALTER TABLE assets drop InvType;

COMMIT;
