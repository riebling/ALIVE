BEGIN;

ALTER TABLE users add email varchar(250);

COMMIT;
