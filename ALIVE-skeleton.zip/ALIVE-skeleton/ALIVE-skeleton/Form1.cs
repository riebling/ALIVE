﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ALIVE;

namespace ALIVE_skeleton
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            SmartDog fido = new SmartDog("Test", "User", "test");

            bool b = fido.Login();
            richTextBox1.AppendText("Login: " + b);
        }
    }
}
